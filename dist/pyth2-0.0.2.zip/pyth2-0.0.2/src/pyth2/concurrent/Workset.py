'''
Created on 2016/03/03

@author: _
'''
from abc import abstractmethod

class Workset(object):
    
    @abstractmethod
    def decompose(self):
        pass
    
    @abstractmethod
    def __organize(self):
        pass

class WorksetBuilder(object):
    pass

class Hoge(object):
    tail = None
    
    def gen(self):
        i = 0
        while True:
            if self.tail:
                yield self.tail
                return
            yield i
            i += 1

a= Hoge()
for x in a.gen():
    print x
    if x == 10000:
        a.tail = True
