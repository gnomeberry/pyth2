'''
Created on 2016/01/31

@author: _
'''

class BaseSchema(object):
    pass