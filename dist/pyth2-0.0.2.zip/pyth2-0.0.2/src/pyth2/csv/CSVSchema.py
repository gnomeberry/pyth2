'''
Created on 2016/01/31

@author: oreyou
'''

class BaseSchema(object):
    pass